export default function Tag({ text, tone }: { text: string; tone?: 'blue'|'green'|'orange'|'gray' }){
  const toneClass = tone === 'green' ? 'bg-green-100 text-green-800'
    : tone === 'orange' ? 'bg-orange-100 text-orange-800'
    : tone === 'gray' ? 'bg-gray-100 text-gray-700'
    : 'bg-sky-100 text-sky-800';
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${toneClass}`}>{text}</span>
}
