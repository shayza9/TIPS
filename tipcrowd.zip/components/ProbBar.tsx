export default function ProbBar({ p }: { p: number }) {
  const pct = Math.round(p * 100);
  return (
    <div className="w-full bg-sky-50 rounded-full h-2 overflow-hidden">
      <div className="h-2 bg-blue-500" style={{ width: `${pct}%` }} />
    </div>
  )
}
