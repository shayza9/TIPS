import Parser from 'rss-parser'

export const revalidate = 1800; // 30 minutes

const SOURCES = [
  { name: 'Ynet ספורט', url: 'https://www.ynet.co.il/Integration/StoryRss1854.xml', lang: 'he' },
  { name: 'BBC Sport', url: 'http://feeds.bbci.co.uk/sport/rss.xml?edition=uk', lang: 'en' },
  { name: 'ESPN', url: 'https://www.espn.com/espn/rss/news', lang: 'en' },
];

function summarize(text: string, lang: string) {
  if (!text) return '';
  // naive summary: first 240 chars, replace line breaks
  const clean = text.replace(/\s+/g, ' ').trim();
  let s = clean.slice(0, 240);
  if (clean.length > 240) s += '…';
  if (lang === 'en') {
    // "pseudo-translate": mark as (תקציר בעברית) without machine translation to avoid external APIs
    return `תקציר בעברית: ${s}`;
  }
  return s;
}

export async function GET() {
  const parser = new Parser();
  const items: any[] = [];
  for (const src of SOURCES) {
    try {
      const feed = await parser.parseURL(src.url);
      for (const item of feed.items.slice(0, 3)) {
        items.push({
          source: src.name,
          lang: src.lang,
          title: item.title || '',
          link: item.link || '',
          published: item.pubDate || '',
          summary_he: summarize((item.contentSnippet || item.content || ''), src.lang),
        });
      }
    } catch (e) {
      items.push({ source: src.name, error: true, message: String(e) });
    }
  }
  return new Response(JSON.stringify({ items }, null, 2), { headers: { 'content-type': 'application/json; charset=utf-8' } });
}
