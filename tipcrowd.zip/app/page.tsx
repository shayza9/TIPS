'use client'
import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { TrendingUp, Newspaper, ShieldCheck, AlertTriangle, Globe2 } from 'lucide-react'
import Tag from '../components/Tag'
import ProbBar from '../components/ProbBar'

type Pick = { id:number; match:string; market:string; outcome:string; p:number; odds:number; ev:number; confidence:string; start:string }
const demoPicks: Pick[] = [
  { id: 1, match: 'מכבי תל אביב vs הפועל באר שבע', market: '1X2', outcome: '1', p: 0.62, odds: 1.85, ev: 0.146, confidence: 'גבוה', start: 'היום 21:00' },
  { id: 2, match: 'ליברפול vs ארסנל', market: 'למעלה/למטה 2.5', outcome: 'למעלה', p: 0.57, odds: 1.95, ev: 0.113, confidence: 'בינוני', start: 'מחר 19:30' },
  { id: 3, match: 'ריאל מדריד vs סוסיאדד', market: 'BTTS', outcome: 'כן', p: 0.59, odds: 1.90, ev: 0.121, confidence: 'גבוה', start: 'מחר 22:00' },
]

type Article = { source:string; title:string; link:string; published:string; summary_he:string; error?:boolean; message?:string }

function PicksTable({ rows }: { rows: Pick[] }){
  return (
    <div className="overflow-hidden rounded-2xl border border-sky-100 bg-white shadow-sm">
      <div className="grid grid-cols-12 p-3 text-xs font-semibold text-sky-700 bg-sky-50">
        <div className="col-span-4">משחק</div>
        <div className="col-span-1">שוק</div>
        <div className="col-span-1">הכרעה</div>
        <div className="col-span-2">הסתברות</div>
        <div className="col-span-1">Odds</div>
        <div className="col-span-1">EV</div>
        <div className="col-span-2">זמן</div>
      </div>
      <div className="divide-y divide-sky-100">
        {rows.map((r) => (
          <div key={r.id} className="grid grid-cols-12 items-center p-3 text-sm">
            <div className="col-span-4 font-medium text-slate-800">{r.match}</div>
            <div className="col-span-1"><Tag text={r.market} /></div>
            <div className="col-span-1"><Tag text={r.outcome} tone="blue" /></div>
            <div className="col-span-2 flex items-center gap-2">
              <ProbBar p={r.p} />
              <span className="w-10 text-end tabular-nums text-slate-700">{Math.round(r.p*100)}%</span>
            </div>
            <div className="col-span-1 tabular-nums text-slate-800">{r.odds.toFixed(2)}</div>
            <div className={`col-span-1 tabular-nums ${r.ev>=0?'text-green-700':'text-red-700'}`}>{r.ev>=0?'+':''}{r.ev.toFixed(3)}</div>
            <div className="col-span-2 flex items-center gap-2">
              <Tag text={r.confidence} tone={r.confidence==='גבוה'?'green':'gray'} />
              <span className="text-slate-600">{r.start}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function Page(){
  const [ageConfirmed, setAgeConfirmed] = useState(false)
  const [articles, setArticles] = useState<Article[]>([])

  useEffect(() => {
    fetch('/api/news').then(r => r.json()).then(data => {
      setArticles(data.items?.filter((x:any) => !x.error) || [])
    }).catch(() => {})
  }, [])

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-sky-50 via-white to-green-50">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/80 border-b border-sky-100">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold">T</div>
            <span className="text-lg font-bold text-slate-900">TipCrowd</span>
            <Tag text="בטא" tone="orange" />
          </div>
          <nav className="hidden md:flex items-center gap-6 text-slate-700">
            <a className="hover:text-slate-900" href="#picks">בחירות היום</a>
            <a className="hover:text-slate-900" href="#news">כתבות</a>
            <a className="hover:text-slate-900" href="#about">עלינו</a>
          </nav>
          <div className="flex items-center gap-2">
            <button className="rounded-xl bg-blue-600 px-4 py-2 text-white text-sm font-semibold hover:bg-blue-700 transition">כניסה</button>
            <button className="rounded-xl bg-sky-100 px-4 py-2 text-sky-800 text-sm font-semibold hover:bg-sky-200 transition">הצטרפות</button>
          </div>
        </div>
      </header>

      {!ageConfirmed && (
        <div className="bg-orange-50 border-y border-orange-200">
          <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3 text-orange-800">
              <AlertTriangle className="w-5 h-5"/>
              <p className="text-sm">תוכן זה מיועד לבני 18+ בלבד. אין לעודד הימורים – משחקים באחריות.</p>
            </div>
            <button onClick={()=>setAgeConfirmed(true)} className="rounded-lg bg-orange-500 text-white text-sm font-semibold px-3 py-1.5 hover:bg-orange-600">אני מאשר/ת</button>
          </div>
        </div>
      )}

      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-5">
            <motion.h1 initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{duration:0.5}} className="text-3xl md:text-4xl font-extrabold text-slate-900 leading-tight">
              חוכמת ההמונים להימורים חוקיים בספורט
            </motion.h1>
            <p className="text-slate-700 text-lg">
              איחוד המלצות ממקורות אמינים, ניקוד ביצועים היסטוריים, חישוב הסתברות וערך צפוי (EV) – בעברית וב-RTL מלא.
            </p>
            <div className="flex flex-wrap gap-2">
              <Tag text="כחול"/> <Tag text="תכלת"/> <Tag text="ירוק" tone="green"/> <Tag text="כתום" tone="orange"/>
            </div>
            <div className="flex gap-3">
              <a href="#picks" className="rounded-xl bg-green-500 px-5 py-2 text-white font-semibold hover:bg-green-600 transition inline-flex items-center gap-2">
                <TrendingUp className="w-5 h-5"/> בחירות היום
              </a>
              <a href="#news" className="rounded-xl bg-sky-100 px-5 py-2 text-sky-800 font-semibold hover:bg-sky-200 transition inline-flex items-center gap-2">
                <Globe2 className="w-5 h-5"/> כתבות מתורגמות
              </a>
            </div>
            <ul className="text-slate-600 text-sm list-disc pr-5 space-y-1">
              <li>שקיפות מלאה בביצועים ומשקלול מקורות</li>
              <li>סיכום יומי של כתבות מובילות בארץ ובעולם</li>
              <li>כיבוד תנאי שימוש, בלי סקרייפינג פראי</li>
            </ul>
          </div>
          <div>
            <div className="rounded-3xl border border-sky-100 bg-white p-5 shadow-sm">
              <div className="rounded-2xl bg-gradient-to-br from-sky-100 via-white to-green-100 p-5">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="text-slate-800 font-semibold">סקור קצר של היום</div>
                    <div className="text-slate-600 text-sm">3 בחירות עם EV חיובי</div>
                  </div>
                  <ShieldCheck className="w-6 h-6 text-green-600"/>
                </div>
                <div className="mt-4 space-y-3">
                  {demoPicks.map(p => (
                    <div key={p.id} className="rounded-xl bg-white/60 border border-sky-100 p-3">
                      <div className="flex items-center justify-between">
                        <div className="text-slate-900 font-semibold">{p.match}</div>
                        <Tag text={`EV ${p.ev>=0?'+':''}${p.ev.toFixed(3)}`} tone={p.ev>=0?'green':'gray'} />
                      </div>
                      <div className="mt-2 grid grid-cols-3 text-sm text-slate-700">
                        <div>שוק: <span className="font-medium">{p.market}</span></div>
                        <div>הכרעה: <span className="font-medium">{p.outcome}</span></div>
                        <div>Odds: <span className="font-medium">{p.odds.toFixed(2)}</span></div>
                      </div>
                      <div className="mt-2"><ProbBar p={p.p} /></div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="picks" className="mx-auto max-w-6xl px-4 pb-12">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">בחירות היום</h2>
            <p className="text-slate-600">קונצנזוס מקורות + חישוב EV. מוצגות דוגמאות.</p>
          </div>
          <button className="rounded-xl bg-blue-600 px-4 py-2 text-white text-sm font-semibold hover:bg-blue-700 transition">ייצוא CSV</button>
        </div>
        <PicksTable rows={demoPicks} />
      </section>

      <section id="news" className="mx-auto max-w-6xl px-4 pb-16">
        <div className="mb-4">
          <h2 className="text-2xl font-bold text-slate-900">כתבות מתורגמות</h2>
          <p className="text-slate-600">2–3 כתבות ביום – תקציר בעברית וקישור למקור.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {articles.slice(0,9).map((a, i) => (
            <a key={i} href={a.link} className="block rounded-2xl border border-sky-100 bg-white p-4 shadow-sm hover:shadow-md transition" dir="rtl">
              <div className="flex items-start gap-3">
                <div className="mt-1"><Newspaper className="w-5 h-5 text-sky-600"/></div>
                <div className="space-y-1">
                  <h3 className="text-slate-900 font-semibold leading-tight">{a.title}</h3>
                  <p className="text-slate-600 text-sm">{a.summary_he}</p>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <Tag text={a.source} tone="orange" />
                    <span>{a.published}</span>
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </section>

      <footer id="about" className="border-t border-sky-100 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-8 grid md:grid-cols-3 gap-6 text-sm">
          <div>
            <div className="text-slate-900 font-bold">TipCrowd</div>
            <p className="text-slate-600 mt-2">תוכן אנליטי ומסכם בלבד. אין לראות במידע ייעוץ להימורים. גיל 18+.</p>
          </div>
          <div>
            <div className="text-slate-900 font-bold">מדיניות</div>
            <ul className="mt-2 space-y-1 text-slate-600">
              <li>אחריות בהימורים • 18+</li>
              <li>כיבוד תנאי שימוש של מקורות חיצוניים</li>
              <li>קרדיט מלא לכתבות עם קישור למקור</li>
            </ul>
          </div>
          <div>
            <div className="text-slate-900 font-bold">קוד פתוח</div>
            <p className="text-slate-600 mt-2">מומלץ להעלות ל-Vercel (חינמי), ולהרחיב בהמשך ל-API/CRON.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
